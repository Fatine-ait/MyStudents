package com.myinitprojectstudents.service;

import org.springframework.stereotype.Component;

import com.myinitprojectstudents.entity.Student;

@Component
public interface StudentService {

	public Student save(Student student);
	
	public Student get(Long id);
	
}
